# PROJECT BRIDGE — Experimental Protocol

## Research objective
Compare human-only and AI-assisted workflows to investigate
whether AI creates measurable operational value for NOVA Retail.

## Experiment A: Customer Enquiry Management
Benchmark: 100 synthetic customer enquiries.

Human-only:
- Read the enquiry and fictional policy.
- Write the response independently.
- Record completion time.

AI-assisted:
- Provide the same enquiry and policy to the AI system.
- Record AI processing time.
- Review and correct the generated response.
- Record total elapsed time and human review time.

Evaluation:
- Policy accuracy.
- Completeness.
- Unsupported claims.
- Escalation correctness.
- Correction count.
- Time and estimated labour cost.

## Experiment B: Customer Feedback Analysis
Benchmark: 120 synthetic customer reviews.

Tasks:
- Sentiment classification.
- Feedback topic classification.

Model input:
- review_text only.

Targets:
- sentiment_label.
- feedback_topic.

Evaluation:
- Accuracy.
- Macro precision.
- Macro recall.
- Macro F1.
- Confusion matrix.
- Processing time.

Use a stratified train/test split.
Keep the test set separate from model training and model selection.

Important limitation:
The labels were manually constructed by one annotator.
Results measure agreement with this synthetic annotation scheme,
not independently verified real-world sentiment.

Do not claim an independent human accuracy comparison unless
a separate reviewer independently labels the test records.

## Experiment C: Product Description Generation
Benchmark: 30 synthetic product records.

Human-only:
- Write a product description using catalogue facts.

AI-assisted:
- Generate a description using the same catalogue facts.
- Review and correct the AI draft.

Evaluation:
- Factual accuracy.
- Completeness.
- Readability.
- Consistency.
- Unsupported claims.
- Human correction time.
- Total completion time.

## Fairness and consistency
- Both workflows receive the same source information.
- Use a fixed task brief and evaluation rubric.
- Record the AI model and version where available.
- Record prompts and model settings.
- Record AI processing time separately from human review time.
- Randomise or alternate task order where practical.
- Do not change evaluation criteria after seeing results.

## Financial evaluation
Calculate labour cost using measured human time and an explicitly
stated hourly labour-rate assumption.

Include AI subscription/API costs and estimated error-related costs
where reliable evidence exists.

Separate measured results from assumptions and projections.

## Research limitations
All three datasets are synthetic.
The experiments are controlled pilot tests, not evidence of
performance in an actual operating business.

- No independently written human baseline was collected.
- The first description set was AI-generated and is labelled Prompt A.

AI-only comparison:
- Prompt A: first AI-generated description set.
- Prompt B: second AI-generated description set using a revised prompt.
- Both approaches used the same 30-product catalogue.

Evaluation criteria:
- Factual accuracy.
- Completeness.
- Unsupported claims.
- Readability.
- Consistency.

Important limitations:
- Both description sets were AI-generated.
- Scores were uniformly prefilled at 2/2 for every criterion.
- These provisional scores are not independent or meaningful
  item-by-item quality measurements.
- No human writing time, AI processing time or review time was measured.
- Results cannot establish productivity gains or financial ROI.

## Actual measurement deviations

### Experiment A
- Human-only completion time was measured for all 100 enquiries.
- Human response quality was scored using the five-criterion rubric.
- AI response quality was also scored using the same rubric.
- Actual AI processing time and human review time were not measured.
- Therefore, the experiment supports a preliminary quality comparison,
  but not a measured time-saving or ROI claim.

### Experiment B
- Logistic Regression and Linear SVM were compared using the same
  stratified train/test splits.
- Logistic Regression was retained because it performed better
  on sentiment classification and matched SVM performance on topic
  classification.
- The test sets contained 24 records per task.
- Results are exploratory because the dataset is small and synthetic.

## Overall methodological limitations

- All three datasets contain fictional, synthetic business data.
- Findings represent a simulated pilot, not verified business outcomes.
- Some evaluations used AI assistance and were not independently validated.
- No real business operating costs or AI service charges were measured.
- Any financial projections must clearly identify their assumptions.
- No real-world causal or generalisable claims should be made.

## Reporting principle

Separate measured observations from assumptions and projections.
Do not present estimated savings, costs or ROI as experimentally
measured results.
