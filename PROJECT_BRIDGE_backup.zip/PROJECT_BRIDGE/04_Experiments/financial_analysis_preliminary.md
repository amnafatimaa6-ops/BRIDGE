# PROJECT BRIDGE — Preliminary Financial Analysis

## 1. Purpose
Estimate the financial conditions under which AI-assisted customer enquiry
management could be economically viable for a simulated small retailer.

## 2. Measured baseline
Experiment A measured human completion time for 100 synthetic enquiries.

- Average human completion time: 55.2 seconds per enquiry.
- Total human completion time: 5,520 seconds (92 minutes).

AI processing time and human review time were not measured.

## 3. Scenario assumptions
The break-even model uses illustrative assumptions:

- Hourly labour costs: PKR 200, 300 and 500.
- AI cost per enquiry: PKR 0, 1 and 5.
- Human-only average completion time: 55.2 seconds.

These values are scenario inputs, not verified market prices or actual
NOVA Retail operating costs.

## 4. Break-even findings
At PKR 300 per labour hour:

- Human-only cost is approximately PKR 4.60 per enquiry.
- With AI costing PKR 1 per enquiry, the maximum break-even human
  review time is 43.2 seconds.
- With AI costing PKR 5 per enquiry, AI costs already exceed the
  human-only baseline before any review labour is included.

At PKR 500 per labour hour and AI cost of PKR 5 per enquiry,
the maximum break-even review time is 19.2 seconds.

## 5. Interpretation
AI adoption is not automatically economical. Its viability depends on
the cost of the AI service and the amount of human review required.

A workflow that produces high-quality responses may still be financially
unattractive if subscription or usage costs are high, or if employees
must spend substantial time checking and correcting outputs.

## 6. Limitations
- AI processing time was not measured.
- Human review time was not measured.
- AI service costs and labour rates are illustrative assumptions.
- No real business revenue, operating expenses or customer outcomes
  were available.
- The model covers customer enquiry management only.
- No experimentally measured ROI or realised savings can be claimed.

## 7. Conclusion
The analysis establishes break-even conditions for possible AI adoption.
It does not establish that AI currently saves money for NOVA Retail.
Actual adoption decisions would require measured AI costs, review time,
correction effort and real business operating data.
