
# PROJECT BRIDGE
## Experiment A — Human Baseline Results

### Sample
100 synthetic customer enquiries were answered manually.

### Time performance
Total human labour time: 5,520 seconds (92 minutes)
Average response time: 55.20 seconds
Median response time: 52.50 seconds

### Overall quality
Average human response quality: 6.85/10

### Quality by criterion
Policy accuracy: 1.39/2
Completeness: 1.68/2
Unsupported claims: 0.51/2
Escalation correctness: 1.27/2
Clarity: 2.00/2

### Quality by complexity
Simple: 7.69/10; average time 23.75 seconds
Moderate: 6.30/10; average time 56.12 seconds
Complex: 6.50/10; average time 100.83 seconds

### Quality by category
Availability: 5.93/10
Cancellation: 7.21/10
Customer Support: 6.93/10
Delivery: 7.07/10
Payment: 5.64/10
Refunds: 7.79/10
Returns: 7.33/10

### Preliminary interpretation
Human responses demonstrated strong clarity but weaker
performance in avoiding unsupported claims. Payment and
availability enquiries showed the lowest average quality.

Simple enquiries were faster and received higher average
quality scores than moderate and complex enquiries.

### Limitations
The dataset is synthetic and represents a simulated retailer.
Quality scoring used a predefined rubric and one evaluator.
The results are pilot findings, not evidence of actual
small-business operational performance.


## Human vs AI Response Quality Comparison

Both human-only and AI-generated responses were evaluated using
the same five-criterion rubric, with a maximum score of 10.

| Criterion | Human Average | AI Average | Difference |
|---|---:|---:|---:|
| Policy accuracy | 1.39/2 | 2.00/2 | +0.61 |
| Completeness | 1.68/2 | 1.95/2 | +0.27 |
| Unsupported claims | 0.51/2 | 2.00/2 | +1.49 |
| Escalation correctness | 1.27/2 | 1.95/2 | +0.68 |
| Clarity | 2.00/2 | 2.00/2 | 0.00 |

The average overall human response quality was 6.85/10,
compared with 9.90/10 for AI-generated responses.

The largest observed difference was in the unsupported-claims
criterion. AI responses consistently followed the supplied
policy constraints, while human responses received lower scores.

These are preliminary findings from a synthetic, controlled
pilot. Responses were evaluated within the same research
workflow, without independent external scoring.

AI processing time and human review time were not measured
reliably; therefore, no measured time-saving or ROI claim
is made at this stage.
