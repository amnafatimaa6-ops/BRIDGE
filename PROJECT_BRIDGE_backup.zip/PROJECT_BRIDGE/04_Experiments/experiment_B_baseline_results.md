
# Experiment B: Customer Feedback Analysis

## Experimental Setup

- Dataset: 120 synthetic customer reviews.
- Training split: 80% (96 reviews).
- Testing split: 20% (24 reviews).
- Random state: 42.
- Text representation: TF-IDF.
- Classification algorithm: Logistic Regression.
- Separate models trained for sentiment and topic classification.
- Test records were excluded from model training.

## Sentiment Classification Results

- Accuracy: 0.8333
- Macro precision: 0.8974
- Macro recall: 0.8155
- Macro F1: 0.8263

### Classification Report

              precision    recall  f1-score   support

    Negative       0.69      1.00      0.82         9
     Neutral       1.00      0.57      0.73         7
    Positive       1.00      0.88      0.93         8

    accuracy                           0.83        24
   macro avg       0.90      0.82      0.83        24
weighted avg       0.88      0.83      0.83        24


## Topic Classification Results

- Accuracy: 0.9167
- Macro precision: 0.9444
- Macro recall: 0.9167
- Macro F1: 0.9111

### Classification Report

                      precision    recall  f1-score   support

    Customer Support       1.00      0.50      0.67         4
            Delivery       1.00      1.00      1.00         4
   Pricing and Value       1.00      1.00      1.00         4
Product Availability       1.00      1.00      1.00         4
     Product Quality       1.00      1.00      1.00         4
 Returns and Refunds       0.67      1.00      0.80         4

            accuracy                           0.92        24
           macro avg       0.94      0.92      0.91        24
        weighted avg       0.94      0.92      0.91        24


## Initial Findings

The sentiment classifier achieved an accuracy of
83.33%. Neutral feedback was
the most difficult category to identify.

The topic classifier achieved an accuracy of
91.67%. Customer Support was the
weakest category, with some reviews incorrectly classified
as Returns and Refunds.

## Limitations

- The dataset contains only 120 synthetic reviews.
- Each classification task has only 24 test observations.
- Synthetic reviews do not establish real-world generalisability.
- Labels were created through a single-annotator process.
- No independent annotation agreement assessment was conducted.
- Results are preliminary baseline measurements.

## Conclusion

TF-IDF with Logistic Regression provides a useful initial
baseline for both feedback classification tasks. Further
evaluation is required before drawing conclusions about
performance on real customer feedback.
