
# Experiment B — Customer Feedback Classification

## 1. Objective

Evaluate whether machine learning can classify synthetic customer
feedback by sentiment and feedback topic.

## 2. Methodology

- Dataset: 120 synthetic customer reviews.
- Input feature: review_text only.
- Sentiment target: sentiment_label.
- Topic target: feedback_topic.
- Training/test split: stratified 80/20.
- Training records: 96 per task.
- Test records: 24 per task.
- Feature extraction: TF-IDF, unigrams and bigrams.
- Models: Logistic Regression and Linear SVM.

## 3. Model Comparison

| Task | Model | Accuracy | Macro F1 |
|---|---|---:|---:|
| Sentiment | Logistic Regression | 0.833 | 0.826 |
| Sentiment | Linear SVM | 0.750 | 0.752 |
| Topic | Logistic Regression | 0.917 | 0.911 |
| Topic | Linear SVM | 0.917 | 0.911 |

## 4. Model Selection

Logistic Regression was retained as the primary model for both tasks.

It achieved better sentiment accuracy than Linear SVM and equivalent
topic-classification performance.

## 5. Error Analysis

Sentiment errors included factual reviews incorrectly classified
as negative and mixed feedback incorrectly classified.

Topic errors involved confusion between Customer Support and
Returns and Refunds.

The original annotations were inspected. No label changes were
made solely to improve model performance.

## 6. Limitations

- The dataset contains only 120 synthetic reviews.
- Each test set contains only 24 records.
- The synthetic dataset is not representative of real customers.
- A single stratified split may produce unstable estimates.
- No independent external validation was performed.
- Results do not establish real-world business performance.

## 7. Conclusion

In this simulated pilot, Logistic Regression achieved 83.3%
sentiment accuracy and 91.7% topic accuracy.

The findings suggest that lightweight text classification can
support preliminary feedback organisation. Human review remains
necessary, particularly for ambiguous sentiment and overlapping
feedback topics.

These results should be treated as exploratory rather than
evidence of production-ready performance.
