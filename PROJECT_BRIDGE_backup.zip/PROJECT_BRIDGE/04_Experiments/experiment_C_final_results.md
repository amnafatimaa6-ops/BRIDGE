# Experiment C — Product Description Generation

## Objective
Compare two AI prompting approaches for generating product descriptions using the same 30-product synthetic catalogue.

## Method
- Dataset: 30 fictional products.
- Prompt A: First AI-generated description set.
- Prompt B: Second AI-generated description set.
- Both sets assessed using the same five criteria, each scored 0–2.
- Criteria: factual accuracy, completeness, unsupported claims, readability and consistency.

## Results

| Metric | Prompt A | Prompt B |
|---|---:|---:|
| Factual accuracy | 2.0 | 2.0 |
| Completeness | 2.0 | 2.0 |
| Unsupported claims | 2.0 | 2.0 |
| Readability | 2.0 | 2.0 |
| Consistency | 2.0 | 2.0 |
| Total average | 10.0/10 | 10.0/10 |

No measurable quality difference was observed between the two prompt approaches.

## Limitations
- All products and catalogue information are synthetic.
- Both description sets were AI-generated; this is not a human-versus-AI experiment.
- Scores were assigned through the same AI-assisted evaluation workflow and are not independent validation.
- No human writing time, AI processing time or review time was measured.
- Results cannot establish real-world productivity gains or financial ROI.

## Conclusion
Both prompt approaches produced descriptions that received identical provisional rubric scores. The experiment demonstrates a structured product-description workflow but does not establish that one prompt is superior. Independent human evaluation would be needed to validate the quality findings.
