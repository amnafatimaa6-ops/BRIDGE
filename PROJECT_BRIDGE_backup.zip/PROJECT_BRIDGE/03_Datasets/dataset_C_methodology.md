# Dataset C — Product Catalogue Methodology

## Overview
Dataset C contains 30 fictional NOVA Retail products.
It supports experiments involving AI-generated product descriptions.

## Composition
- 30 products.
- Six retail categories.
- Five products per category.
- Prices recorded in fictional Pakistani rupee listings.

## Product information
Each record contains product identity, category, price,
material, colour, specifications, key features, approved
claims, unsupported claims and target customer information.

## Experimental use
The catalogue is the factual reference source for product
description generation.

AI-generated descriptions will be evaluated against the
catalogue for:
- Factual accuracy.
- Completeness.
- Readability.
- Consistency.
- Unsupported or invented claims.

## Important distinction
Approved claims represent information supported by this
synthetic catalogue. Prohibited claims represent statements
for which the catalogue provides no supporting evidence.

A claim not supported by the catalogue must not be presented
as an established product fact.

## Limitations
1. All products and specifications are synthetic.
2. The catalogue does not represent actual retail inventory.
3. Product claims have not been independently verified.
4. The six categories have equal representation by design.
5. Results cannot establish performance on real commercial
   product catalogues without further testing.

## Research use
Dataset C is a controlled pilot dataset for comparing
human-written and AI-assisted product descriptions.