# Dataset B — Customer Feedback Methodology

## 1. Dataset Overview

Dataset B contains 120 synthetic customer reviews created
for Project BRIDGE, using the fictional business NOVA Retail.

The dataset was designed to support two classification tasks:
1. Sentiment classification.
2. Customer feedback topic classification.

The records were created in four batches of 30 reviews.

## 2. Dataset Composition

Total records: 120

Topics:
- Delivery: 20
- Product Quality: 20
- Customer Support: 20
- Returns and Refunds: 20
- Pricing and Value: 20
- Product Availability: 20

Sentiment distribution:
- Negative: 45
- Positive: 40
- Neutral: 35

## 3. Sentiment Annotation Rules

Positive:
The review expresses clear satisfaction, praise, or a favourable
judgement about the customer's experience.

Negative:
The review expresses dissatisfaction, criticism, or an unresolved
problem.

Neutral:
The review reports information or describes an event without
clearly expressing satisfaction or dissatisfaction.

Each review includes a short label rationale explaining its
assigned sentiment.

## 4. Rating Information

Ratings are synthetic auxiliary variables and are not treated
as ground-truth sentiment labels.

During the rating-versus-sentiment audit, ratings for ten
factual neutral reviews were revised to reduce extreme numerical
ratings attached to comments without an explicit evaluation.

Final rating distribution:
- 1 star: 0
- 2 stars: 26
- 3 stars: 64
- 4 stars: 28
- 5 stars: 2

The rating distribution is a design characteristic of this
synthetic dataset. It should not be interpreted as representative
of actual customer behaviour.

## 5. Intended Model Inputs and Targets

Sentiment classification:
- Input: review_text
- Target: sentiment_label

Topic classification:
- Input: review_text
- Target: feedback_topic

The following columns are excluded from the primary text-only
classification inputs:
- review_id
- rating
- label_rationale

Excluding label_rationale helps prevent information leakage
because it directly explains the assigned sentiment.

## 6. Data Quality Checks

The final dataset contains:
- 120 records
- 6 columns
- 120 unique review IDs
- No missing values
- No duplicate rows
- Ratings within the permitted 1–5 range
- Valid sentiment and topic labels

## 7. Limitations

1. The dataset is synthetic, not collected from actual customers.
2. Reviews and labels were manually constructed and assigned.
3. Independent annotator validation was not conducted.
4. Inter-annotator agreement could not be measured.
5. Every topic has exactly 20 records, unlike potentially
   uneven real-world customer feedback.
6. The rating distribution is intentionally designed and is
   not representative of a real retail population.
7. Each review is assigned one primary topic, although actual
   customer reviews may discuss several topics.
8. Model results on this dataset cannot establish how well a
   system will perform on genuine customer reviews.

## 8. Research Use

Dataset B is a controlled synthetic pilot dataset for testing
the feasibility of automated customer feedback classification
within Project BRIDGE.

Any model performance results must be reported as results on
this synthetic dataset, not as evidence of real-world business
performance.